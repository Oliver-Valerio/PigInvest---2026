/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.domain;
/**
 *
 * @author oliver160307
 */
public enum StatusAporte {
    ATIVO("Ativo"),
    CANCELADO("Cancelado"),
    ENCERRADO("Encerrado");

    private String descricao;

    StatusAporte(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}

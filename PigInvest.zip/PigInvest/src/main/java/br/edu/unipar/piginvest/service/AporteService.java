/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.service;
import java.math.BigDecimal;
import java.time.LocalDate;
import br.edu.unipar.piginvest.domain.Aporte;
import br.edu.unipar.piginvest.domain.ContaDigital;
import br.edu.unipar.piginvest.domain.ProdutoInvestimento;
import br.edu.unipar.piginvest.exception.PigInvestException;
import br.edu.unipar.piginvest.repository.AporteRepository;
import br.edu.unipar.piginvest.repository.ContaDigitalRepository;
import br.edu.unipar.piginvest.repository.ProdutoInvestimentoRepository;
/**
 *
 * @author oliver160307
 */
public class AporteService {

    private AporteRepository aporteRepository;
    private ContaDigitalRepository contaRepository;
    private ProdutoInvestimentoRepository produtoRepository;

    public AporteService() {
        this.aporteRepository = new AporteRepository();
        this.contaRepository = new ContaDigitalRepository();
        this.produtoRepository = new ProdutoInvestimentoRepository();
    }

    // CASO DE USO: REALIZAR APORTE
    public Aporte realizarAporte(int idUsuario, int idProduto, BigDecimal valorInvestido, int qtdProduto) {

        if (valorInvestido == null || valorInvestido.compareTo(BigDecimal.ZERO) <= 0) {
            throw new PigInvestException("O valor do aporte deve ser maior que zero.");
        }

        ContaDigital conta = contaRepository.buscarPorIdUsuario(idUsuario);
        if (conta == null) {
            throw new PigInvestException("Conta digital não encontrada para o usuário.");
        }

        if (conta.getSaldoDisponivel().compareTo(valorInvestido) < 0) {
            throw new PigInvestException("[M11] Saldo insuficiente para realizar esta operação.");
        }

        ProdutoInvestimento produto = produtoRepository.buscarPorId(idProduto);
        if (produto == null) {
            throw new PigInvestException("Produto de investimento não encontrado.");
        }

        Aporte aporte = new Aporte(idUsuario, idProduto, valorInvestido, LocalDate.now(), qtdProduto);
        aporteRepository.inserir(aporte);

        conta.setSaldoDisponivel(conta.getSaldoDisponivel().subtract(valorInvestido));
        contaRepository.atualizar(conta);

        System.out.println("✔ Aporte realizado com sucesso!");
        System.out.println("✔ Produto: " + produto.getNomeProduto());
        System.out.println("✔ Valor investido: R$" + valorInvestido);
        System.out.println("✔ Saldo restante: R$" + conta.getSaldoDisponivel());

        return aporte;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.domain;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author oliver160307
 */
public class Aporte {

    private int idAporte;
    private int idUsuario;
    private int idProduto;
    private BigDecimal valorInvestido;
    private LocalDate dataAporte;
    private String status;
    private int qtdProduto;
    
    public Aporte() {}

    public Aporte(int idUsuario, int idProduto, BigDecimal valorInvestido, LocalDate dataAporte, int qtdProduto) {
        this.idUsuario = idUsuario;
        this.idProduto = idProduto;
        this.valorInvestido = valorInvestido;
        this.dataAporte = dataAporte;
        this.status = "Ativo";
        this.qtdProduto = qtdProduto;
    }

    public int getIdAporte() { return idAporte; }
    public void setIdAporte(int idAporte) { this.idAporte = idAporte; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public int getIdProduto() { return idProduto; }
    public void setIdProduto(int idProduto) { this.idProduto = idProduto; }

    public BigDecimal getValorInvestido() { return valorInvestido; }
    public void setValorInvestido(BigDecimal valorInvestido) { this.valorInvestido = valorInvestido; }

    public LocalDate getDataAporte() { return dataAporte; }
    public void setDataAporte(LocalDate dataAporte) { this.dataAporte = dataAporte; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getQtdProduto() { return qtdProduto; }
    public void setQtdProduto(int qtdProduto) { this.qtdProduto = qtdProduto; }

    @Override
    public String toString() {
        return "Aporte{id=" + idAporte + ", usuario=" + idUsuario + ", produto=" + idProduto
                + ", valor=R$" + valorInvestido + ", data=" + dataAporte + ", status=" + status + "}";
    }
}

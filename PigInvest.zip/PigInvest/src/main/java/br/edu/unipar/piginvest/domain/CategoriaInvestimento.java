package br.edu.unipar.piginvest.domain;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

/**
 *
 * @author oliver160307
 */
public enum CategoriaInvestimento {
    RENDA_FIXA("Renda Fixa"),
    RENDA_VARIAVEL("Renda Variável"),
    FUNDOS_IMOBILIARIOS("Fundos Imobiliários"),
    ACOES("Ações"),
    CRIPTOMOEDAS("Criptomoedas");

    private String descricao;

    CategoriaInvestimento(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}

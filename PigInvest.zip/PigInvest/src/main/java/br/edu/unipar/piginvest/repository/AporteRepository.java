/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import br.edu.unipar.piginvest.domain.Aporte;
import br.edu.unipar.piginvest.exception.PigInvestException;
import br.edu.unipar.piginvest.infrastructure.ConexaoBanco;
/**
 *
 * @author oliver160307
 */
public class AporteRepository implements IAporteRepository {
    
    @Override
    public void inserir(Aporte aporte) {
        String sql = "INSERT INTO aporte (id_usuario, id_produto, valor_investido, data_aporte, status, qtd_produto) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, aporte.getIdUsuario());
            stmt.setInt(2, aporte.getIdProduto());
            stmt.setBigDecimal(3, aporte.getValorInvestido());
            stmt.setDate(4, Date.valueOf(aporte.getDataAporte()));
            stmt.setString(5, aporte.getStatus());
            stmt.setInt(6, aporte.getQtdProduto());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                aporte.setIdAporte(rs.getInt(1));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao inserir aporte: " + e.getMessage());
        }
    }
    
    @Override
    public Aporte buscarPorId(int id) {
        String sql = "SELECT * FROM aporte WHERE id_aporte = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapear(rs);
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao buscar aporte: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public List<Aporte> listarTodos() {
        List<Aporte> lista = new ArrayList<>();
        String sql = "SELECT * FROM aporte";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao listar aportes: " + e.getMessage());
        }
        return lista;
    }
    
    @Override
    public List<Aporte> listarPorUsuario(int idUsuario) {
        List<Aporte> lista = new ArrayList<>();
        String sql = "SELECT * FROM aporte WHERE id_usuario = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao listar aportes do usuário: " + e.getMessage());
        }
        return lista;
    }
    
    @Override
    public void atualizar(Aporte aporte) {
        String sql = "UPDATE aporte SET valor_investido=?, status=?, qtd_produto=? WHERE id_aporte=?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setBigDecimal(1, aporte.getValorInvestido());
            stmt.setString(2, aporte.getStatus());
            stmt.setInt(3, aporte.getQtdProduto());
            stmt.setInt(4, aporte.getIdAporte());
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao atualizar aporte: " + e.getMessage());
        }
    }
    
    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM aporte WHERE id_aporte = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao deletar aporte: " + e.getMessage());
        }
    }

    private Aporte mapear(ResultSet rs) throws SQLException {
        Aporte a = new Aporte();
        a.setIdAporte(rs.getInt("id_aporte"));
        a.setIdUsuario(rs.getInt("id_usuario"));
        a.setIdProduto(rs.getInt("id_produto"));
        a.setValorInvestido(rs.getBigDecimal("valor_investido"));
        a.setDataAporte(rs.getDate("data_aporte").toLocalDate());
        a.setStatus(rs.getString("status"));
        a.setQtdProduto(rs.getInt("qtd_produto"));
        return a;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import br.edu.unipar.piginvest.domain.Usuario;
import br.edu.unipar.piginvest.exception.PigInvestException;
import br.edu.unipar.piginvest.infrastructure.ConexaoBanco;
/**
 *
 * @author oliver160307
 */
public class UsuarioRepository implements IUsuarioRepository{
    
    @Override
    public void inserir(Usuario usuario) {
        String sql = "INSERT INTO usuario (nome_completo, email, senha_hash, celular, celular_verificado, biometria_ativa, perfil_investidor, codigo_convite, data_cadastro) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, usuario.getNomeCompleto());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getSenhaHash());
            stmt.setString(4, usuario.getCelular());
            stmt.setBoolean(5, usuario.isCelularVerificado());
            stmt.setBoolean(6, usuario.isBiometriaAtiva());
            stmt.setString(7, usuario.getPerfilInvestidor());
            stmt.setString(8, usuario.getCodigoConvite());
            stmt.setDate(9, Date.valueOf(usuario.getDataCadastro()));
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                usuario.setIdUsuario(rs.getInt(1));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao inserir usuário: " + e.getMessage());
        }
    }
    
    @Override
    public Usuario buscarPorId(int id) {
        String sql = "SELECT * FROM usuario WHERE id_usuario = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapear(rs);
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao buscar usuário: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public Usuario buscarPorEmail(String email) {
        String sql = "SELECT * FROM usuario WHERE email = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapear(rs);
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao buscar usuário por email: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public List<Usuario> listarTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuario";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao listar usuários: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public void atualizar(Usuario usuario) {
        String sql = "UPDATE usuario SET nome_completo=?, email=?, senha_hash=?, celular=?, perfil_investidor=? WHERE id_usuario=?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getNomeCompleto());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getSenhaHash());
            stmt.setString(4, usuario.getCelular());
            stmt.setString(5, usuario.getPerfilInvestidor());
            stmt.setInt(6, usuario.getIdUsuario());
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao atualizar usuário: " + e.getMessage());
        }
    }
    
    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM usuario WHERE id_usuario = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao deletar usuário: " + e.getMessage());
        }
    }

    private Usuario mapear(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setIdUsuario(rs.getInt("id_usuario"));
        u.setNomeCompleto(rs.getString("nome_completo"));
        u.setEmail(rs.getString("email"));
        u.setSenhaHash(rs.getString("senha_hash"));
        u.setCelular(rs.getString("celular"));
        u.setCelularVerificado(rs.getBoolean("celular_verificado"));
        u.setBiometriaAtiva(rs.getBoolean("biometria_ativa"));
        u.setPerfilInvestidor(rs.getString("perfil_investidor"));
        u.setCodigoConvite(rs.getString("codigo_convite"));
        u.setDataCadastro(rs.getDate("data_cadastro").toLocalDate());
        return u;
    }
}
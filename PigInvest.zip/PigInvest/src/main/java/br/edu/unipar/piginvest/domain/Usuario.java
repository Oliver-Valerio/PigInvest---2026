/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.domain;
import java.time.LocalDate;
/**
 *
 * @author oliver160307
 */
public class Usuario {

    private int idUsuario;
    private String nomeCompleto;
    private String email;
    private String senhaHash;
    private String celular;
    private boolean celularVerificado;
    private boolean biometriaAtiva;
    private String perfilInvestidor;
    private String codigoConvite;
    private LocalDate dataCadastro;
    
    public Usuario() {}

    public Usuario(String nomeCompleto, String email, String senhaHash, LocalDate dataCadastro) {
        this.nomeCompleto = nomeCompleto;
        this.email = email;
        this.senhaHash = senhaHash;
        this.dataCadastro = dataCadastro;
        this.celularVerificado = false;
        this.biometriaAtiva = false;
    }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public String getNomeCompleto() { return nomeCompleto; }
    public void setNomeCompleto(String nomeCompleto) { this.nomeCompleto = nomeCompleto; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenhaHash() { return senhaHash; }
    public void setSenhaHash(String senhaHash) { this.senhaHash = senhaHash; }

    public String getCelular() { return celular; }
    public void setCelular(String celular) { this.celular = celular; }

    public boolean isCelularVerificado() { return celularVerificado; }
    public void setCelularVerificado(boolean celularVerificado) { this.celularVerificado = celularVerificado; }

    public boolean isBiometriaAtiva() { return biometriaAtiva; }
    public void setBiometriaAtiva(boolean biometriaAtiva) { this.biometriaAtiva = biometriaAtiva; }

    public String getPerfilInvestidor() { return perfilInvestidor; }
    public void setPerfilInvestidor(String perfilInvestidor) { this.perfilInvestidor = perfilInvestidor; }

    public String getCodigoConvite() { return codigoConvite; }
    public void setCodigoConvite(String codigoConvite) { this.codigoConvite = codigoConvite; }

    public LocalDate getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(LocalDate dataCadastro) { this.dataCadastro = dataCadastro; }

    @Override
    public String toString() {
        return "Usuario{id=" + idUsuario + ", nome=" + nomeCompleto + ", email=" + email + "}";
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import br.edu.unipar.piginvest.domain.ProdutoInvestimento;
import java.util.List;
/**
 *
 * @author oliver160307
 */
public interface IProdutoInvestimentoRepository {
    void inserir(ProdutoInvestimento produto);
    ProdutoInvestimento buscarPorId(int id);
    List<ProdutoInvestimento> listarTodos();
    void atualizar(ProdutoInvestimento produto);
    void deletar(int id);
}

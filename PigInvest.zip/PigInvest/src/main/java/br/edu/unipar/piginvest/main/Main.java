/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.main;
import java.math.BigDecimal;
import java.util.Scanner;
import br.edu.unipar.piginvest.domain.Aporte;
import br.edu.unipar.piginvest.domain.ContaDigital;
import br.edu.unipar.piginvest.domain.Usuario;
import br.edu.unipar.piginvest.exception.PigInvestException;
import br.edu.unipar.piginvest.repository.ContaDigitalRepository;
import br.edu.unipar.piginvest.repository.ProdutoInvestimentoRepository;
import br.edu.unipar.piginvest.service.AporteService;
import br.edu.unipar.piginvest.service.UsuarioService;
/**
 *
 * @author oliver160307
 */
public class Main {

    static Scanner scanner = new Scanner(System.in);
    static UsuarioService usuarioService = new UsuarioService();
    static AporteService aporteService = new AporteService();
    static Usuario usuarioLogado = null;

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("        Bem-vindo ao Pig Invest!        ");
        System.out.println("========================================");

        boolean rodando = true;
        while (rodando) {
            if (usuarioLogado == null) {
                System.out.println("\n1 - Criar conta");
                System.out.println("2 - Entrar na conta");
                System.out.println("0 - Sair");
                System.out.print("Escolha: ");
                String opcao = scanner.nextLine();

                switch (opcao) {
                    case "1": criarConta(); break;
                    case "2": login(); break;
                    case "0": rodando = false; break;
                    default: System.out.println("Opção inválida!");
                }
            } else {
                System.out.println("\n--- Dashboard de " + usuarioLogado.getNomeCompleto() + " ---");
                System.out.println("1 - Realizar aporte");
                System.out.println("2 - Ver saldo");
                System.out.println("3 - Ver meus aportes");
                System.out.println("4 - Logout");
                System.out.println("0 - Sair");
                System.out.print("Escolha: ");
                String opcao = scanner.nextLine();

                switch (opcao) {
                    case "1": realizarAporte(); break;
                    case "2": verSaldo(); break;
                    case "3": verAportes(); break;
                    case "4": usuarioLogado = null; System.out.println("Logout realizado!"); break;
                    case "0": rodando = false; break;
                    default: System.out.println("Opção inválida!");
                }
            }
        }

        System.out.println("\nObrigado por usar o Pig Invest. Até logo!");
    }

    private static void criarConta() {
        System.out.println("\n--- Cadastro ---");
        System.out.print("Nome completo: ");
        String nome = scanner.nextLine();
        System.out.print("E-mail: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();

        try {
            usuarioLogado = usuarioService.criarConta(nome, email, senha);
        } catch (PigInvestException e) {
            System.out.println("✖ Erro: " + e.getMessage());
        }
    }

    private static void login() {
        System.out.println("\n--- Login ---");
        System.out.print("E-mail: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();

        try {
            usuarioLogado = usuarioService.login(email, senha);
        } catch (PigInvestException e) {
            System.out.println("✖ Erro: " + e.getMessage());
        }
    }

    private static void realizarAporte() {
        System.out.println("\n--- Novo Aporte ---");

        // Lista produtos disponíveis
        ProdutoInvestimentoRepository produtoRepo = new ProdutoInvestimentoRepository();
        System.out.println("Produtos disponíveis:");
        produtoRepo.listarTodos().forEach(p -> System.out.println("  [" + p.getIdProduto() + "] " + p.getNomeProduto() + " - " + p.getCategoria() + " - " + p.getRentabilidadeEstimada() + "% a.a."));

        System.out.print("ID do produto: ");
        int idProduto = Integer.parseInt(scanner.nextLine());
        System.out.print("Valor a investir: R$");
        BigDecimal valor = new BigDecimal(scanner.nextLine());
        System.out.print("Quantidade: ");
        int qtd = Integer.parseInt(scanner.nextLine());

        try {
            Aporte aporte = aporteService.realizarAporte(usuarioLogado.getIdUsuario(), idProduto, valor, qtd);
        } catch (PigInvestException e) {
            System.out.println("✖ Erro: " + e.getMessage());
        }
    }

    private static void verSaldo() {
        ContaDigitalRepository contaRepo = new ContaDigitalRepository();
        ContaDigital conta = contaRepo.buscarPorIdUsuario(usuarioLogado.getIdUsuario());
        if (conta != null) {
            System.out.println("\n💰 Saldo disponível: R$" + conta.getSaldoDisponivel());
        } else {
            System.out.println("Conta não encontrada.");
        }
    }

    private static void verAportes() {
        br.edu.unipar.piginvest.repository.AporteRepository aporteRepo = new br.edu.unipar.piginvest.repository.AporteRepository();
        System.out.println("\n--- Meus Aportes ---");
        aporteRepo.listarPorUsuario(usuarioLogado.getIdUsuario()).forEach(a -> System.out.println(a));
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.domain;

/**
 *
 * @author oliver160307
 */
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransacaoConta {

    private int idTransacao;
    private int idConta;
    private Integer idAporte;
    private String tipoTransacao;
    private BigDecimal valor;
    private LocalDateTime dataHora;

    public TransacaoConta() {}

    public TransacaoConta(int idConta, Integer idAporte, String tipoTransacao, BigDecimal valor, LocalDateTime dataHora) {
        this.idConta = idConta;
        this.idAporte = idAporte;
        this.tipoTransacao = tipoTransacao;
        this.valor = valor;
        this.dataHora = dataHora;
    }

    public int getIdTransacao() { return idTransacao; }
    public void setIdTransacao(int idTransacao) { this.idTransacao = idTransacao; }

    public int getIdConta() { return idConta; }
    public void setIdConta(int idConta) { this.idConta = idConta; }

    public Integer getIdAporte() { return idAporte; }
    public void setIdAporte(Integer idAporte) { this.idAporte = idAporte; }

    public String getTipoTransacao() { return tipoTransacao; }
    public void setTipoTransacao(String tipoTransacao) { this.tipoTransacao = tipoTransacao; }

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }

    @Override
    public String toString() {
        return "Transacao{id=" + idTransacao + ", tipo=" + tipoTransacao + ", valor=R$" + valor + ", dataHora=" + dataHora + "}";
    }
}
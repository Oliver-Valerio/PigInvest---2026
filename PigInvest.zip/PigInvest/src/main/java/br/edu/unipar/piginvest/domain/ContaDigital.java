/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.domain;
import java.math.BigDecimal;
/**
 *
 * @author oliver160307
 */
public class ContaDigital {

    private int idConta;
    private int idUsuario;
    private BigDecimal saldoDisponivel;

    public ContaDigital() {}

    public ContaDigital(int idUsuario) {
        this.idUsuario = idUsuario;
        this.saldoDisponivel = BigDecimal.ZERO;
    }

    public int getIdConta() { return idConta; }
    public void setIdConta(int idConta) { this.idConta = idConta; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public BigDecimal getSaldoDisponivel() { return saldoDisponivel; }
    public void setSaldoDisponivel(BigDecimal saldoDisponivel) { this.saldoDisponivel = saldoDisponivel; }

    @Override
    public String toString() {
        return "ContaDigital{id=" + idConta + ", saldo=R$" + saldoDisponivel + "}";
    }
}

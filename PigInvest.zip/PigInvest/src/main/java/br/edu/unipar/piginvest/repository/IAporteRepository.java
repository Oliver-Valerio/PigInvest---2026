/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import java.util.List;
import br.edu.unipar.piginvest.domain.Aporte;
/**
 *
 * @author oliver160307
 */
public interface IAporteRepository {
    void inserir(Aporte aporte);
    Aporte buscarPorId(int id);
    List<Aporte> listarTodos();
    List<Aporte> listarPorUsuario(int idUsuario);
    void atualizar(Aporte aporte);
    void deletar(int id);
}

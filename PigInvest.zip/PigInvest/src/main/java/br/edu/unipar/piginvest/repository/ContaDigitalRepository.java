/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import br.edu.unipar.piginvest.domain.ContaDigital;
import br.edu.unipar.piginvest.exception.PigInvestException;
import br.edu.unipar.piginvest.infrastructure.ConexaoBanco;
/**
 *
 * @author oliver160307
 */
public class ContaDigitalRepository implements IContaDigitalRepository {
    
    @Override
    public void inserir(ContaDigital conta) {
        String sql = "INSERT INTO conta_digital (id_usuario, saldo_disponivel) VALUES (?, ?)";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, conta.getIdUsuario());
            stmt.setBigDecimal(2, conta.getSaldoDisponivel());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                conta.setIdConta(rs.getInt(1));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao inserir conta: " + e.getMessage());
        }
    }
    
    @Override
    public ContaDigital buscarPorId(int id) {
        String sql = "SELECT * FROM conta_digital WHERE id_conta = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapear(rs);
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao buscar conta: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public ContaDigital buscarPorIdUsuario(int idUsuario) {
        String sql = "SELECT * FROM conta_digital WHERE id_usuario = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapear(rs);
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao buscar conta por usuário: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public List<ContaDigital> listarTodos() {
        List<ContaDigital> lista = new ArrayList<>();
        String sql = "SELECT * FROM conta_digital";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao listar contas: " + e.getMessage());
        }
        return lista;
    }
    
    @Override
    public void atualizar(ContaDigital conta) {
        String sql = "UPDATE conta_digital SET saldo_disponivel = ? WHERE id_conta = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setBigDecimal(1, conta.getSaldoDisponivel());
            stmt.setInt(2, conta.getIdConta());
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao atualizar conta: " + e.getMessage());
        }
    }
    
    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM conta_digital WHERE id_conta = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao deletar conta: " + e.getMessage());
        }
    }

    private ContaDigital mapear(ResultSet rs) throws SQLException {
        ContaDigital c = new ContaDigital();
        c.setIdConta(rs.getInt("id_conta"));
        c.setIdUsuario(rs.getInt("id_usuario"));
        c.setSaldoDisponivel(rs.getBigDecimal("saldo_disponivel"));
        return c;
    }
}

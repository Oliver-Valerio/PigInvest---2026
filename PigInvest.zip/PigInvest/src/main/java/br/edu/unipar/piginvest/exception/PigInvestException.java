/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.exception;

/**
 *
 * @author oliver160307
 */
public class PigInvestException extends RuntimeException {
    public PigInvestException(String mensagem) {
        super(mensagem);
    }
}

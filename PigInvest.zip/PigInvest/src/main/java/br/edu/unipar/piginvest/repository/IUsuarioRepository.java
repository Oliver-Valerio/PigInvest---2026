/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import br.edu.unipar.piginvest.domain.Usuario;
import java.util.List;
/**
 *
 * @author oliver160307
 */
public interface IUsuarioRepository {
    void inserir(Usuario usuario);
    Usuario buscarPorId(int id);
    Usuario buscarPorEmail(String email);
    List<Usuario> listarTodos();
    void atualizar(Usuario usuario);
    void deletar(int id);
}
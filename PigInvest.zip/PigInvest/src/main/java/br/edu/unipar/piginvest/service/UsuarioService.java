/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.service;
import java.time.LocalDate;
import br.edu.unipar.piginvest.domain.ContaDigital;
import br.edu.unipar.piginvest.domain.Usuario;
import br.edu.unipar.piginvest.exception.PigInvestException;
import br.edu.unipar.piginvest.repository.ContaDigitalRepository;
import br.edu.unipar.piginvest.repository.UsuarioRepository;
/**
 *
 * @author oliver160307
 */
public class UsuarioService {

    private UsuarioRepository usuarioRepository;
    private ContaDigitalRepository contaRepository;

    public UsuarioService() {
        this.usuarioRepository = new UsuarioRepository();
        this.contaRepository = new ContaDigitalRepository();
    }

    // CASO DE USO: CRIAR CONTA
    public Usuario criarConta(String nomeCompleto, String email, String senha) {

        if (nomeCompleto == null || nomeCompleto.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            senha == null || senha.trim().isEmpty()) {
            throw new PigInvestException("[M02] Por favor, preencha todos os campos obrigatórios.");
        }

        if (!email.contains("@") || !email.contains(".")) {
            throw new PigInvestException("[M02] E-mail inválido. Informe um e-mail no formato correto.");
        }

        if (senha.length() < 6) {
            throw new PigInvestException("[M02] A senha deve ter pelo menos 6 caracteres.");
        }

        Usuario existente = usuarioRepository.buscarPorEmail(email);
        if (existente != null) {
            throw new PigInvestException("[M02] E-mail já cadastrado. Utilize outro e-mail.");
        }

        Usuario novoUsuario = new Usuario(nomeCompleto, email, senha, LocalDate.now());
        usuarioRepository.inserir(novoUsuario);

        ContaDigital conta = new ContaDigital(novoUsuario.getIdUsuario());
        contaRepository.inserir(conta);

        System.out.println("✔ Conta criada com sucesso! Bem-vindo(a), " + nomeCompleto + "!");
        System.out.println("✔ Sua conta digital foi criada com saldo R$0,00.");

        return novoUsuario;
    }

    // CASO DE USO: LOGIN
    public Usuario login(String email, String senha) {

        if (email == null || email.trim().isEmpty() ||
            senha == null || senha.trim().isEmpty()) {
            throw new PigInvestException("[M02] Por favor, preencha todos os campos obrigatórios.");
        }

        Usuario usuario = usuarioRepository.buscarPorEmail(email);

        if (usuario == null || !usuario.getSenhaHash().equals(senha)) {
            throw new PigInvestException("[M01] E-mail ou senha incorretos.");
        }

        System.out.println("✔ Login realizado com sucesso! Bem-vindo(a), " + usuario.getNomeCompleto() + "!");

        return usuario;
    }
}
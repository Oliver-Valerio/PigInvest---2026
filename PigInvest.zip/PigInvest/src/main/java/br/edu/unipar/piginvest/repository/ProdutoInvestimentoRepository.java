/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import br.edu.unipar.piginvest.domain.ProdutoInvestimento;
import br.edu.unipar.piginvest.exception.PigInvestException;
import br.edu.unipar.piginvest.infrastructure.ConexaoBanco;
/**
 *
 * @author oliver160307
 */
public class ProdutoInvestimentoRepository implements IProdutoInvestimentoRepository{
    
    @Override
    public void inserir(ProdutoInvestimento produto) {
        String sql = "INSERT INTO produto_investimento (nome_produto, categoria, rentabilidade_estimada) VALUES (?, ?, ?)";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, produto.getNomeProduto());
            stmt.setString(2, produto.getCategoria());
            stmt.setBigDecimal(3, produto.getRentabilidadeEstimada());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                produto.setIdProduto(rs.getInt(1));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao inserir produto: " + e.getMessage());
        }
    }
    
    @Override
    public ProdutoInvestimento buscarPorId(int id) {
        String sql = "SELECT * FROM produto_investimento WHERE id_produto = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapear(rs);
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao buscar produto: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public List<ProdutoInvestimento> listarTodos() {
        List<ProdutoInvestimento> lista = new ArrayList<>();
        String sql = "SELECT * FROM produto_investimento";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao listar produtos: " + e.getMessage());
        }
        return lista;
    }
    
    @Override
    public void atualizar(ProdutoInvestimento produto) {
        String sql = "UPDATE produto_investimento SET nome_produto=?, categoria=?, rentabilidade_estimada=? WHERE id_produto=?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, produto.getNomeProduto());
            stmt.setString(2, produto.getCategoria());
            stmt.setBigDecimal(3, produto.getRentabilidadeEstimada());
            stmt.setInt(4, produto.getIdProduto());
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao atualizar produto: " + e.getMessage());
        }
    }
    
    @Override
    public void deletar(int id) {
        String sql = "DELETE FROM produto_investimento WHERE id_produto = ?";
        try (Connection conn = ConexaoBanco.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new PigInvestException("Erro ao deletar produto: " + e.getMessage());
        }
    }

    private ProdutoInvestimento mapear(ResultSet rs) throws SQLException {
        ProdutoInvestimento p = new ProdutoInvestimento();
        p.setIdProduto(rs.getInt("id_produto"));
        p.setNomeProduto(rs.getString("nome_produto"));
        p.setCategoria(rs.getString("categoria"));
        p.setRentabilidadeEstimada(rs.getBigDecimal("rentabilidade_estimada"));
        return p;
    }
}

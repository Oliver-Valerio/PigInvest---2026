/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.unipar.piginvest.domain;

/**
 *
 * @author oliver160307
 */
import java.math.BigDecimal;

public class ProdutoInvestimento {

    private int idProduto;
    private String nomeProduto;
    private String categoria;
    private BigDecimal rentabilidadeEstimada;

    public ProdutoInvestimento() {}

    public ProdutoInvestimento(String nomeProduto, String categoria, BigDecimal rentabilidadeEstimada) {
        this.nomeProduto = nomeProduto;
        this.categoria = categoria;
        this.rentabilidadeEstimada = rentabilidadeEstimada;
    }

    public int getIdProduto() { return idProduto; }
    public void setIdProduto(int idProduto) { this.idProduto = idProduto; }

    public String getNomeProduto() { return nomeProduto; }
    public void setNomeProduto(String nomeProduto) { this.nomeProduto = nomeProduto; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public BigDecimal getRentabilidadeEstimada() { return rentabilidadeEstimada; }
    public void setRentabilidadeEstimada(BigDecimal rentabilidadeEstimada) { this.rentabilidadeEstimada = rentabilidadeEstimada; }

    @Override
    public String toString() {
        return "Produto{id=" + idProduto + ", nome=" + nomeProduto + ", categoria=" + categoria + ", rentabilidade=" + rentabilidadeEstimada + "%}";
    }
}

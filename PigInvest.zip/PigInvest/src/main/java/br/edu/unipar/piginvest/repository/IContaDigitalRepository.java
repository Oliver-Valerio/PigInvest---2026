/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.edu.unipar.piginvest.repository;
import br.edu.unipar.piginvest.domain.ContaDigital;
import java.util.List;
/**
 *
 * @author oliver160307
 */

public interface IContaDigitalRepository {
    void inserir(ContaDigital conta);
    ContaDigital buscarPorId(int id);
    ContaDigital buscarPorIdUsuario(int idUsuario);
    List<ContaDigital> listarTodos();
    void atualizar(ContaDigital conta);
    void deletar(int id);
}